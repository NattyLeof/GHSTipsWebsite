# GHSTipsWebsite
A website detailing tips that all Grant High School students should know. 


Please do not take this too seriously. 

Created by Nathaniel Leof while attending Grant Highschool. Class of 2018. 


